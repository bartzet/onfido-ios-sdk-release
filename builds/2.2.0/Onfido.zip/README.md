# Summary

This README file is a work in progress that will contain the instructions on the organisation of the Onfido iOS SDK, how to get setup for development, how to run the SDK in various different modes and other details that will enable a developer mainly but even non developers to manage themselves around this project.

## Getting started

**TODO**

This section will contain the necessary instructions to enable you to run the project, including pre-requisites.

### Pre-requisites

This section will contain all the pre-requisites for developing and running the Onfido iOS SDK.

## Running

The app contains multiple targets, some of them are to run the app in different modes and others for testing. This section will cover the targets to enable you to run the SDK. For testing please visit the [testing section](#testing).

### Targets

The targets of interest to run the SDK are:

1. HostApplication

  This target mimics an app integrating with the Onfido iOS SDK. The SDK is imported as a framework. The Onfido iOS SDK dependencies are fulfilled via cocoapods `Podfile` (see entry for HostApplication). This is the ideal target to use when providing an app for acceptance testing as this target is the closest to the integration experience of our customers.

2. OnfidoApp

  The OnfidoApp target is an iOS app that copies across all the files of SDK without compiling them into a dynamic framework first. This allows for easy debugging by adding breakpoints in the SDK's code which will be recognised by Xcode, whereas in the compiled form it does not work. If you are developing I suggest that you use this target whilst adding or amending features.

3. OnfidoDemoApp

  The OnfidoDemoApp target is an iOS app that copies all the sources of the SDK into a single target just like the OnfidoApp. This app's purpose is for distribution, at the time of writing only to members of the growth team. The reason that we copy across the source files is so we could add feature request quickly to the app for quick demo purposes, although at the time of writing nothing from SDK source files is being leveraged by the app. We want to keep compiling the SDK's source files in this app for flexibility delivering new features without messing a lot with the SDK itself.


## Testing

**TODO**

This section will contain instructions on how to run the different tests in the project.

## Deploying

**TODO**

This section will contain instructions on what deployment methods are supported for the different targets and the how to's.

### HostApplication

This app for acceptance testing only. At the time of writing we only manually deploy this target to the different stakeholders that wish to test either the latest changes in development or in a feature branch.

### OnfidoApp

This app is for development only and not to be distributed to any stakeholders. All OnfidoApp specific files can be changed to the developers will to ease development of features.

Even though this app is the one that offers the most flexibility to the developer and is not constrained by other stakeholders or design, please only commit code around this app that will ease the development of all features and not just one.

### OnfidoDemoApp

This is the app distributed externally from the Input Capture Team (currently only to growth with maybe more to come). The app is distributed currently only via HockeyApp which is platform to distribute apps to testers.

#### Pre-requisites
**TODO**
