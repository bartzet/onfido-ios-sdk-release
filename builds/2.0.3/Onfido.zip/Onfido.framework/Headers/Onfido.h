//
//  Onfido.h
//  Onfido
//
//  Created by Anurag Ajwani on 16/12/2016.
//  Copyright © 2016 Anurag Ajwani. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Onfido.
FOUNDATION_EXPORT double OnfidoVersionNumber;

//! Project version string for Onfido.
FOUNDATION_EXPORT const unsigned char OnfidoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Onfido/PublicHeader.h>


